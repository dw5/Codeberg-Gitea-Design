COPYRIGHT
Logo material is licensed under CC-BY http://creativecommons.org/licenses/by/4.0/
Codeberg and the Codeberg Logo are trademarks of Codeberg e.V


PLEASE DO THESE THINGS
+ Use the logo to link to your Codeberg repository
+ Pick and chose the best fit from the logo-kit
+ Print the logo on t-shirts and mugs because you think we are great :D


PLEASE, DON'T DO THESE THINGS
- Deform the logo by stretching, compressing or skewing
- Tint the logo in a custom color
- Put the logo on a background that is noisy or has a poor contrast
- Detach and rearrange the logosymbol & logotype


GET IN TOUCH
If you have questions about usage please just get in touch with us. Also if you miss any particular format or material to promote Codeberg just get in touch with us!
